"""
Intraday Trade Cancellation — Reference Design
================================================

Architecture Summary:
- CancellationRecord stored in ephemeral MongoDB collection (cancellations_<date>)
- CancellationEvent published to Kafka (enriched topic or dedicated intraday.events topic — TBD)
- Timestamp-based replay filtering with parity-toggle for multiple cancellation cycles
- Data-layer deletes affected trades on cancellation write
- Cancellation endpoint is transactional: rolls back data-layer write if Kafka produce fails

Services affected:
- Intraday service: cancellation endpoint, rewind filter
- Data-layer service: new cancellation CRUD + trade deletion on cancel
- Calculator services: live cancellation handling + replay filter
"""

from __future__ import annotations

import uuid
from collections import defaultdict, deque
from datetime import datetime, date
from enum import Enum
from typing import ClassVar

from pydantic import BaseModel, Field


# =============================================================================
# Models
# =============================================================================


class CancellationRecord(BaseModel):
    """Stored in MongoDB: cancellations_<date> collection."""

    cancellation_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    deal_number: str
    portfolio: str
    versions: list[int]  # specific versions being cancelled (all > 0)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    created_by: str  # support user identifier


class CancellationRequest(BaseModel):
    """Incoming request from support UI."""

    deal_number: str
    portfolio: str
    versions: list[int]
    requested_by: str


class CancellationEvent(BaseModel):
    """
    New variant in the EventEnvelope discriminated union.
    Published to Kafka so calculators receive it in-stream (live)
    and can also encounter it during replay.
    """

    event_type: ClassVar[str] = "intraday_cancellation"

    cancellation_id: str
    deal_number: str
    portfolio: str
    versions: list[int]
    created_at: datetime
    created_by: str

    @classmethod
    def from_record(cls, record: CancellationRecord) -> CancellationEvent:
        return cls(
            cancellation_id=record.cancellation_id,
            deal_number=record.deal_number,
            portfolio=record.portfolio,
            versions=record.versions,
            created_at=record.created_at,
            created_by=record.created_by,
        )


# Key type used throughout for cancellation lookups
TradeKey = tuple[str, str, int]  # (deal_number, portfolio, version)


# =============================================================================
# Cancellation Endpoint (Intraday Service)
# =============================================================================


async def cancel_intraday_trades(
    request: CancellationRequest,
    data_layer_client,  # async HTTP client to data-layer service
    kafka_producer,     # EventsClient or similar
    internal_state,     # intraday service's in-memory trade state
) -> CancellationRecord:
    """
    Cancellation endpoint handler.

    Transactional flow:
    1. Write CancellationRecord to data-layer (which also deletes affected trades)
    2. Produce CancellationEvent to Kafka
    3. If Kafka fails → roll back data-layer write → return error
    4. Remove trades from internal state
    5. Return 200
    """
    record = CancellationRecord(
        deal_number=request.deal_number,
        portfolio=request.portfolio,
        versions=request.versions,
        created_by=request.requested_by,
    )

    # Step 1: Write cancellation + delete trades in data-layer
    # Data-layer handles both atomically and returns error if either fails
    try:
        await data_layer_client.post_cancellation(record)
    except Exception:
        raise  # Let FastAPI exception handler return 500

    # Step 2: Produce to Kafka
    event = CancellationEvent.from_record(record)
    try:
        await kafka_producer.produce(
            topic=f"enriched_intradays_{date.today().isoformat()}",
            # Or: topic="intraday.events" — TBD with team
            event=event,
        )
    except Exception:
        # Step 3: Roll back data-layer write
        await data_layer_client.rollback_cancellation(record.cancellation_id)
        raise  # Return error to support UI

    # Step 4: Remove from internal state (only after both succeed)
    for version in request.versions:
        key = (request.deal_number, request.portfolio, version)
        internal_state.remove(key)

    return record


# =============================================================================
# Cancellation Filter — Used by both Intraday Service and Calculators on replay
# =============================================================================


class CancellationFilter:
    """
    Timestamp-based replay filter with parity-toggle for multiple
    cancellation cycles per key.

    Usage:
        1. Fetch CancellationRecords from data-layer on startup
        2. Build filter: CancellationFilter.from_records(records)
        3. For each message during replay: filter.should_process(key, msg_timestamp)

    How it works:
        For each trade key, cancellation timestamps divide the timeline into
        alternating zones:

            |--- SKIP ---|--- PROCESS ---|--- SKIP ---|--- PROCESS ---| ...
                       cancel_1        cancel_2      cancel_3

        Messages before the first cancellation are skipped (they were cancelled).
        Messages between cancel_1 and cancel_2 are processed (valid re-adds).
        Messages between cancel_2 and cancel_3 are skipped (cancelled again).
        And so on.

        The filter tracks this as a boolean parity that toggles each time
        we cross a cancellation timestamp boundary.

    Nuclear recovery scenario:
        If topics are deleted and recreated, all new message timestamps
        postdate all cancellation timestamps. The filter will toggle through
        all cancellation boundaries immediately, ending in PROCESS state
        (for even number of cancellations) or SKIP state (for odd).
        With odd cancellations (the common case — one cancel, no re-add yet),
        new messages postdate the single cancel → toggle to PROCESS. Correct.
    """

    def __init__(self) -> None:
        # Per-key queue of cancellation timestamps, sorted ascending
        self._cancel_queues: dict[TradeKey, deque[datetime]] = defaultdict(deque)
        # Per-key current cancelled state.
        # True = currently in a cancelled zone (skip messages)
        self._cancelled: dict[TradeKey, bool] = {}

    @classmethod
    def from_records(cls, records: list[CancellationRecord]) -> CancellationFilter:
        """
        Build filter from cancellation records fetched from data-layer.
        Records should be sorted by created_at ascending.
        """
        instance = cls()

        # Group and sort cancellation timestamps per trade key
        key_timestamps: dict[TradeKey, list[datetime]] = defaultdict(list)
        for record in records:
            for version in record.versions:
                key = (record.deal_number, record.portfolio, version)
                key_timestamps[key].append(record.created_at)

        for key, timestamps in key_timestamps.items():
            timestamps.sort()
            instance._cancel_queues[key] = deque(timestamps)
            # Any key with cancellation records starts in CANCELLED state
            # (everything before the first cancellation timestamp is invalid)
            instance._cancelled[key] = True

        return instance

    def should_process(self, key: TradeKey, message_timestamp: datetime) -> bool:
        """
        Determine whether a replayed message should be processed or skipped.

        Advances past any cancellation boundaries that the message timestamp
        has crossed, toggling the parity each time.
        """
        if key not in self._cancel_queues and key not in self._cancelled:
            # No cancellations for this key — always process
            return True

        queue = self._cancel_queues.get(key)
        if queue:
            while queue and message_timestamp >= queue[0]:
                queue.popleft()
                self._cancelled[key] = not self._cancelled[key]

        return not self._cancelled.get(key, False)


# =============================================================================
# Intraday Service — Rewind (Restart Recovery)
# =============================================================================


async def intraday_service_rewind(
    raw_topic_consumer,     # Kafka consumer for raw_intradays_<date>
    data_layer_client,      # async HTTP client
    internal_state,         # intraday service's in-memory trade state
    transform_fn,           # raw → structured trade model
    trading_date: date,
) -> None:
    """
    Replay raw_intradays_<date> to rebuild internal state.
    Does NOT re-produce to enriched topic.
    """
    # Step 1: Fetch cancellation ledger from data-layer
    records = await data_layer_client.get_cancellations(trading_date)
    cancellation_filter = CancellationFilter.from_records(records)

    # Step 2: Replay raw topic from beginning
    raw_topic_consumer.seek_to_beginning()

    for raw_msg in raw_topic_consumer:
        trade = transform_fn(raw_msg)
        key: TradeKey = (trade.deal_number, trade.portfolio, trade.version)

        # Only process version > 0 through cancellation filter
        if trade.version > 0:
            if not cancellation_filter.should_process(key, raw_msg.timestamp):
                continue  # Skip: this message is in a cancelled zone

        internal_state.add(trade)


# =============================================================================
# Calculator Service — Live Cancellation Handling
# =============================================================================


async def calculator_handle_cancellation(
    event: CancellationEvent,
    engine,  # calculation engine instance
) -> None:
    """
    Handle CancellationEvent received during live consumption.
    Called between ticks — current tick completes before this runs.
    """
    for version in event.versions:
        engine.remove_trade(
            deal_number=event.deal_number,
            portfolio=event.portfolio,
            version=version,
        )


# =============================================================================
# Calculator Service — Replay (Restart / New Instance)
# =============================================================================


async def calculator_replay(
    enriched_topic_consumer,   # Kafka consumer for enriched_intradays_<date>
    data_layer_client,         # async HTTP client
    engine,                    # calculation engine instance
    trading_date: date,
) -> None:
    """
    Replay enriched_intradays_<date> to rebuild calculator state.
    Also loads version==0 trades from data-layer.
    """
    # Step 1: Load base trades (version==0) from data-layer
    base_trades = await data_layer_client.get_trades(trading_date, version=0)
    for trade in base_trades:
        engine.add_trade(trade)

    # Step 2: Fetch cancellation ledger
    records = await data_layer_client.get_cancellations(trading_date)
    cancellation_filter = CancellationFilter.from_records(records)

    # Step 3: Replay enriched topic
    enriched_topic_consumer.seek_to_beginning()

    for msg in enriched_topic_consumer:
        # Handle CancellationEvents encountered during replay
        if isinstance(msg, CancellationEvent):
            # The filter already accounts for this via the data-layer records,
            # but we process the event to maintain consistency in case
            # the data-layer fetch was slightly stale
            for version in msg.versions:
                key: TradeKey = (msg.deal_number, msg.portfolio, version)
                # Ensure any already-ingested trades for this key are removed
                engine.remove_trade(
                    deal_number=msg.deal_number,
                    portfolio=msg.portfolio,
                    version=version,
                )
            continue

        # Regular enriched trade message
        trade = msg  # already structured
        key = (trade.deal_number, trade.portfolio, trade.version)

        if trade.version > 0:
            if not cancellation_filter.should_process(key, msg.timestamp):
                continue

        engine.add_trade(trade)


# =============================================================================
# Data-Layer Service — New Endpoints
# =============================================================================


class CancellationCRUD:
    """
    Reference for new data-layer endpoints.
    Collection: cancellations_<date> (ephemeral, dropped on day rollover)
    """

    async def post_cancellation(
        self,
        record: CancellationRecord,
        db,  # motor async MongoDB client
        trading_date: date,
    ) -> None:
        """
        Transactional: insert cancellation record AND delete affected trades.
        Uses MongoDB multi-document transaction.
        """
        collection_name = f"cancellations_{trading_date.isoformat()}"
        trades_collection = db["trades"]  # or however your collection is named

        async with await db.client.start_session() as session:
            async with session.start_transaction():
                # Insert cancellation record
                await db[collection_name].insert_one(
                    record.model_dump(),
                    session=session,
                )

                # Delete affected trades
                await trades_collection.delete_many(
                    {
                        "deal_number": record.deal_number,
                        "portfolio": record.portfolio,
                        "version": {"$in": record.versions},
                    },
                    session=session,
                )

    async def rollback_cancellation(
        self,
        cancellation_id: str,
        db,
        trading_date: date,
    ) -> None:
        """
        Rollback: remove cancellation record.
        Note: trade deletion cannot be trivially rolled back — the trades
        are already gone. Consider whether you need to restore them
        (e.g., from the Kafka topic via replay) or if the support team
        will simply re-submit the cancellation.
        """
        collection_name = f"cancellations_{trading_date.isoformat()}"
        await db[collection_name].delete_one({"cancellation_id": cancellation_id})

    async def get_cancellations(
        self,
        db,
        trading_date: date,
    ) -> list[CancellationRecord]:
        """Fetch all cancellation records for a trading day, sorted by created_at."""
        collection_name = f"cancellations_{trading_date.isoformat()}"
        cursor = db[collection_name].find().sort("created_at", 1)
        docs = await cursor.to_list(length=None)
        return [CancellationRecord(**doc) for doc in docs]


# =============================================================================
# Open Items / Notes
# =============================================================================

"""
DECIDED:
- Timestamp-based filtering (not offset-based) for nuclear recovery support
- At-least-once Kafka delivery; event system deduplicates
- Cancellation endpoint is transactional: data-layer + Kafka, rollback on failure
- Data-layer deletes trades as part of cancellation write
- Calculator current tick completes before cancellation is applied
- Cancellation ledger is ephemeral per trading day
- Support provides explicit version list in cancellation request

TBD WITH TEAM:
- CancellationEvent destination: enriched_intradays_<date> vs dedicated intraday.events topic
  - If separate topic: calculators need to consume both, but ordering is handled
    by timestamp filter + data-layer ledger anyway
  - If same topic: simpler consumer loop, but enriched topic is no longer pure trade data

ROLLBACK CAVEAT:
- rollback_cancellation removes the CancellationRecord but the trades have
  already been deleted from the trades collection in the same transaction.
  If Kafka produce fails and we roll back, we need to decide:
  (a) Also restore the deleted trades (requires storing them before deletion, e.g., soft-delete)
  (b) Accept that trades are gone and require support to re-trigger the full flow
  Current approach: (b) — support re-submits. If (a) is needed, switch to
  soft-delete (add a "cancelled" flag) instead of hard-delete.

RE-ADD FLOW (Q17 — deferred):
- How re-added trades enter the system after cancellation is TBD.
- If via normal raw topic flow: works naturally with timestamp filter.
- If via dedicated endpoint: may bypass raw topic entirely; needs separate
  enriched topic production path.
"""
