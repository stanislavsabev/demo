This is a great problem — it's essentially about introducing a retroactive invalidation into an append-only, replay-based system. Let me share my initial thinking and then hit you with the questions that matter.
Initial Design Sketch
The core tension: your Kafka topics are append-only and replayed from the beginning on recovery, but cancellation needs to retroactively invalidate earlier messages with the same keys. The natural solution is a cancellation ledger that acts as a filter during replay.
The flow I'm envisioning:

Support hits the cancellation endpoint on the Intraday service with (deal_number, portfolio) — cancel all versions > 0.
Intraday service writes a CancellationRecord to a new MongoDB collection via the data-layer (timestamp, deal_number, portfolio, affected versions, cancelled_by, etc.).
Intraday service produces a CancellationEvent to the enriched_intradays_<date> topic (so calculators see it in-order during live consumption AND during replay).
Intraday service removes the trades from its own internal state.
Calculators, on receiving the CancellationEvent, remove matching trades from their engines.
On replay (service restart / new calculator spin-up): before processing the topic from the beginning, the service fetches the cancellation ledger from the data-layer. During replay, any enriched intraday message whose key matches a cancellation record AND whose offset/timestamp is before the cancellation timestamp gets skipped. Messages after the cancellation (re-adds with same keys) pass through.

This means the cancellation ledger + timestamp comparison becomes the reconciliation mechanism that bridges the gap between "immutable topic" and "mutable state."

Clarifying & Design Questions
On the cancellation scope and identity:

You said cancellation targets deal_number + portfolio with version > 0. Is it always all versions > 0 for that pair, or could support need to cancel a specific subset of versions? This changes whether the ledger key is (deal_number, portfolio) or (deal_number, portfolio, version).
When the same keys get re-added after cancellation — is there any distinguishing field on the new trade (a sequence number, a different timestamp in the raw data)? Or is it literally byte-identical to the original except it arrives after the cancellation? This is critical for replay disambiguation.

On ordering and the replay contract:

The CancellationEvent on the enriched topic — should it be a new discriminated union variant in your existing EventEnvelope, or are you thinking a separate event type entirely? I'd lean toward a new variant (IntradayCancellation) in the same envelope so your existing consumer dispatch loop handles it naturally.
During calculator replay, is it safe to assume the calculator processes messages strictly in offset order? If so, the replay logic is straightforward: encounter a CancellationEvent → build a "cancelled keys" set with timestamp → retroactively remove already-ingested trades from the engine AND skip future messages with matching keys that predate the cancellation. But if there's any parallelism or partitioning that could reorder things, we need a different approach.
Does the Intraday service also replay raw_intradays_<date> from the beginning on restart, or does it use the data-layer as its recovery source? This determines whether the cancellation ledger needs to be consulted during raw topic replay too.

On consistency and edge cases:

What happens if the Intraday service crashes between writing the cancellation to MongoDB and producing the CancellationEvent to Kafka? Do you want to design for exactly-once semantics here (outbox pattern), or is at-least-once with idempotent handling acceptable?
If a calculator is mid-tick when the cancellation arrives, is it acceptable for the current tick to complete with the stale trades, and removal happens before the next tick? Or do you need immediate interruption?
End-of-day: when topics rotate to a new date, do cancellation records need to survive, or is the ledger ephemeral per trading day?

The answers to questions 2 and 6 are probably the most architecturally significant — they determine whether you need an outbox pattern and how sophisticated the replay filter logic needs to be. What's your thinking?Answers:
Q1: It may be just a subset of versions unfortunately.
Q2: It maybe exactly the same with time of arrival as only discriminator.
Q6: At least once is fine - event system handles (ignores) duplicate events.
Q5: Yes, intraday service also replays and also needs to load cancellation events from the data-layer.
Q7: It is acceptable for current tick to complete.
Q8: Ledger is ephemeral per trading day
Q4: Yes, messages are processed in order, there are not that many intradays anyway. Up to 2-3 thousand per day.12:02 PMGood, these answers clarify a lot. Let me refine the design and then push on the remaining hard problem — which is Q2, because that's where the real complexity lives.
Refined Design
CancellationRecord in MongoDB (per trading day, ephemeral collection):
python# cancellations_<date> collection
{
    "cancellation_id": "uuid",
    "deal_number": str,
    "portfolio": str,
    "versions": [int, ...],        # specific subset of versions cancelled
    "cancelled_at": datetime,       # server timestamp of cancellation
    "cancelled_by": str,            # support user / system
    "kafka_offset_marker": int | None,  # offset of the CancellationEvent on enriched topic, backfilled after produce
}
CancellationEvent (new variant in your EventEnvelope discriminated union):
Goes onto enriched_intradays_<date> so calculators see it in-stream. Contains the same fields as the record above.
Replay logic (both Intraday service and Calculators):

On startup, fetch all CancellationRecords from data-layer for the current date.
Replay topic from beginning. For each message:

If it's a CancellationEvent → register it in local cancellation state (same as fetched records, but ensures consistency if data-layer fetch was stale).
If it's a trade message → check if (deal_number, portfolio, version) is in the cancelled set. If yes, need to determine: is this message before or after the cancellation?




The Hard Problem: Replay Disambiguation
This is where your answer to Q2 makes things interesting. If re-added trades are byte-identical to originals, and the only discriminator is arrival time, then during replay we need to know which side of the cancellation a given trade message falls on.
The most reliable approach I see: use Kafka offset as the ordering discriminator, not timestamps.
The CancellationEvent lands at a specific offset on enriched_intradays_<date>. During replay, any trade message matching a cancelled key tuple that appears at an offset before the CancellationEvent's offset gets skipped. Any matching message at an offset after gets processed (it's a re-add).
This is clean because offsets are monotonic and unambiguous within a partition. No clock skew concerns.
The replay filter becomes:
python# pseudocode during replay
for msg in topic.replay():
    if isinstance(msg, CancellationEvent):
        for v in msg.versions:
            cancellation_offsets[(msg.deal_number, msg.portfolio, v)] = msg.offset
        engine.remove_trades(msg.deal_number, msg.portfolio, msg.versions)
    
    elif isinstance(msg, EnrichedIntraday):
        key = (msg.deal_number, msg.portfolio, msg.version)
        cancel_offset = cancellation_offsets.get(key)
        if cancel_offset is not None and msg.offset < cancel_offset:
            continue  # skip: this predates the cancellation
        engine.add_trade(msg)
But here's the edge case that worries me: what if there are multiple cancellation cycles for the same key in one day? Support cancels versions [3, 5], they get re-added, then support cancels them again. Now you have two CancellationEvents for the same key tuple, and messages between them that should be processed then un-processed.

Follow-up Questions
Q3 (from before, still open): I'm assuming this becomes a new variant in your existing EventEnvelope discriminated union — does that align with your current events-lib structure?
Q9: Can multiple cancellation cycles for the same key happen in a single day? If yes, the offset-based approach needs to track a list of cancellation offsets per key and do interval-based filtering (trade is valid only if it falls after the most recent cancellation). Manageable but worth confirming.
Q10: When the Intraday service replays raw_intradays_<date>, it re-transforms and re-produces to the enriched topic. Should it skip producing for cancelled-then-not-re-added trades during replay? Otherwise you'd get duplicate enriched messages on the topic. Or does the Intraday service use the data-layer to detect "I already produced this" and avoid re-producing on replay?
Q11: The cancellation endpoint — should it be synchronous (wait for Kafka produce confirmation + data-layer write before responding 200), or fire-and-forget with an async status check? Given this is a support-facing tool, I'd lean toward synchronous with a reasonable timeout.
Q10 is the one I'd think about carefully — it touches on your replay idempotency guarantees for the Intraday service itself.Answers:
Q3 - yes,
Q9 - yes, but I still insist on using the timestamp
Q10 -Two things here:intraday service replays raw topic messages in a "rewinding" mode (a bool flag) in order to re-build it's internal state, but it does not reproduce to the enriched topic. It only appends to it new messages.yes it should skip messages for cancelled trades - as if they never arrieved.  When "rewinding" if  incoming messages timestamp is after current cancel event "created_at| time, the event should be poped from the event list (read from the data-layer)  and the next event should be considered as current when checking for trades to ignore.my guess, and the reason I want to stick to timestamps,  is that this approach will work even in case of an extreme circumstance, where the services are stopped, topics are deleted and re-created with all new messages. In this case all timestamps on the messages will be after the cancellation events timestamps which will "invalidate" them. This is fine and part of the requirements.
Q11 - ideally yes - I am looking for some kind of transactional element here.Show more12:50 PMThe timestamp reasoning is solid — you're designing for the "nuclear recovery" scenario where topics get recreated, and timestamps give you that invariant: if the world is rebuilt from scratch, all new message timestamps postdate existing cancellation records, so the cancellations become no-ops. Offset-based filtering would break completely in that case. I'm convinced.
Refined Replay Logic with Timestamps and Multiple Cancellation Cycles
Let me make sure I understand your mental model for the "event list" approach during rewind, because this is the crux:
python# On startup (rewind mode):
# 1. Fetch cancellations from data-layer, sorted by created_at ASC
# 2. Build a per-key queue of cancellation timestamps

# Structure:
# key = (deal_number, portfolio, version)
# cancel_queue[key] = deque([cancel_ts_1, cancel_ts_2, ...])  # ascending

# 3. Replay raw topic:
for msg in raw_topic.replay():
    key = (msg.deal_number, msg.portfolio, msg.version)
    
    if key in cancel_queue and cancel_queue[key]:
        current_cancel_ts = cancel_queue[key][0]
        
        if msg.timestamp < current_cancel_ts:
            # Message predates the current cancellation → skip
            continue
        else:
            # Message arrived after (or at) cancellation time
            # Pop this cancellation — it's been "consumed"
            cancel_queue[key].popleft()
            
            # Now check: is there ANOTHER cancellation ahead?
            # If so, this message is a re-add that was later cancelled again
            if cancel_queue[key]:
                next_cancel_ts = cancel_queue[key][0]
                if msg.timestamp < next_cancel_ts:
                    # Valid re-add (between two cancellations) → process
                    process(msg)
                else:
                    # Actually this postdates the next cancel too — 
                    # need to keep popping?
                    ...
            else:
                # No more cancellations — message is a valid re-add
                process(msg)
Wait — there's a subtlety here. The "pop and check next" approach works cleanly for simple cases but gets tricky with multiple rapid cancellation cycles. Let me think about this differently.
A cleaner model might be: for each key, the cancellation timestamps divide the timeline into alternating zones: CANCELLED → VALID → CANCELLED → VALID → .... A message is valid if it falls in a VALID zone (after an odd-numbered cancellation boundary has been "consumed").
Actually, I think the simplest correct version is:
python# For each key, cancellations are ordered: [ts_1, ts_2, ts_3, ...]
# Messages before ts_1: SKIP (original trades, cancelled)
# Messages between ts_1 and ts_2: PROCESS (re-adds after first cancel)  
# Messages between ts_2 and ts_3: SKIP (re-adds that got cancelled again)
# Messages after ts_3: PROCESS
# Pattern: odd-index cancellations start a SKIP zone, even-index start PROCESS

# But since we're streaming in order, the deque-pop approach works:
# - While message timestamp >= front of deque: pop
# - After popping, count how many you popped
# - If you popped an odd number total so far: process. Even: skip.

# Actually even simpler — just track parity:
cancel_events: dict[Key, deque[datetime]]  # sorted ASC
cancelled_state: dict[Key, bool]  # starts True for any key with cancellations

for msg in replay():
    key = (msg.deal_number, msg.portfolio, msg.version)
    
    # Advance past any cancellation timestamps we've passed
    while cancel_events.get(key) and msg.timestamp >= cancel_events[key][0]:
        cancel_events[key].popleft()
        cancelled_state[key] = not cancelled_state[key]
    
    if cancelled_state.get(key, False):
        continue  # in a cancelled zone
    
    process(msg)
Does this match your mental model? The key insight is that cancelled_state starts True for any key that has cancellation records (meaning: everything before the first cancellation is invalid), and toggles every time we cross a cancellation boundary.

Remaining Design Questions
Q12: The transactional element on the cancellation endpoint — are you thinking: (a) write to MongoDB first, then produce to Kafka, and if Kafka fails you compensate by deleting the MongoDB record? Or (b) outbox pattern — write to MongoDB (including an "outbox" document), then a background process picks up the outbox and produces to Kafka? Given your at-least-once tolerance, option (a) with a retry on the Kafka produce is probably sufficient, but I want to confirm you don't need the stronger guarantee.
Q13: When the Intraday service receives the cancellation request, it needs to know which versions to cancel. Does the support team provide the explicit version list in the request, or does the Intraday service need to look up "all current versions > 0 for this deal_number + portfolio" from its internal state or the data-layer?
Q14: Should calculators also fetch the cancellation ledger on startup (like the Intraday service does), or is replaying the enriched topic from the beginning — which now contains CancellationEvent messages — sufficient for them to reconstruct the correct state? I'd lean toward "both" for defense in depth, but if you trust the enriched topic as the calculator's source of truth, topic-only might be cleaner.On the subtle element with rapid cancellations: This is highly unlikely. Cancellation will be done manually from an UI and there will be 1 to 10 of those per day. Even 10 is maybe to high. Q12: I don't need such strong guarantee
Q13: Yes trade keys are provided in the request
Q14: I'd say yes. I'm also thinking of posting cancellation events to a separate intraday.events topic and not to the enriched topic, but this I need to discuss with other team members.12:57 PMGood — the low frequency of cancellations simplifies things considerably. The parity-toggle approach is still correct but you won't need to stress-test rapid-fire edge cases in practice.
On Q14 and the separate intraday.events topic idea — that's actually a meaningful architectural choice worth thinking through before you discuss with the team. Let me lay out the tradeoffs so you have ammunition for that conversation.
Cancellation events on enriched_intradays_<date> (same topic):

Calculators get cancellations in-order relative to trade messages during replay — no cross-topic ordering concerns.
Single consumer loop, single replay pass.
But it "pollutes" the enriched topic with non-trade messages, which changes the topic's semantic contract.

Separate intraday.events topic:

Clean separation of concerns — enriched topic stays pure trade data.
But now calculators must consume two topics and reason about cross-topic ordering during replay. Since Kafka gives you ordering guarantees only within a partition of a single topic, you'd need to fall back on timestamps to merge the two streams correctly during replay. Which you're already doing anyway.
The Intraday service rewind would also need to consume this second topic (or rely solely on the data-layer ledger).

Given that you're already committed to timestamp-based filtering with the data-layer as the cancellation source of truth, the separate topic actually works fine — calculators don't strictly need the cancellation events in-stream during replay because they fetch the ledger on startup. The separate topic then serves as the live notification channel for running calculators, while the data-layer serves replay.
That's a clean separation: live path via Kafka, recovery path via data-layer. Worth raising with the team.

Design Summary So Far
Let me consolidate what we've converged on:
New MongoDB collection (ephemeral, per trading day): cancellations_<date> storing CancellationRecord documents with cancellation_id, deal_number, portfolio, versions: list[int], created_at, created_by.
Cancellation endpoint flow (Intraday service):

Receive request with deal_number, portfolio, versions list.
Write CancellationRecord to data-layer.
Produce CancellationEvent to Kafka (enriched topic or intraday.events — TBD).
Remove affected trades from Intraday service's internal state.
Return 200 after steps 2 and 3 succeed. Retry Kafka produce on transient failure.

CancellationEvent: New discriminated union variant in your EventEnvelope. Contains deal_number, portfolio, versions, created_at.
Calculator live path: Receives CancellationEvent from Kafka, removes matching trades from engine before next tick.
Intraday service rewind (restart recovery):

Fetch all CancellationRecords from data-layer for current date.
Build per-key cancellation queues (sorted by created_at).
Replay raw_intradays_<date>, using the timestamp-toggle filter to skip cancelled messages and process valid re-adds.
Do not re-produce to enriched topic during rewind.

Calculator replay (restart/new instance):

Fetch cancellation ledger from data-layer.
Fetch version==0 trades from data-layer.
Replay enriched_intradays_<date> with same timestamp-toggle filter.

Nuclear recovery (topics deleted and recreated): All new message timestamps postdate cancellation records, so all cancellations effectively become no-ops — the filter skips nothing, which is correct because the recreated messages represent the current desired state.

Final Questions
Q15: For step 5 of the endpoint flow — if the data-layer write succeeds but Kafka produce fails after N retries, should the endpoint return an error and leave the data-layer record in place (so at least replay is correct, and the Kafka event can be retried or manually triggered later)? Or should it roll back the data-layer write?
Q16: Do you want the cancellation endpoint to also trigger deletion of the affected trades from the data-layer's trade collection, or just insert the cancellation record and let the natural replay/reconciliation handle the rest? I'd lean toward explicit deletion for consistency — the data-layer should reflect reality immediately, not eventually.
Q17: When support re-adds trades after cancellation with the same keys — do those come in through the normal raw_intradays_<date> flow, or through a separate mechanism? If normal flow, the Intraday service just processes them as fresh trades and the timestamp-toggle filter naturally handles it on future replays.Q15: Roll back data-layer write and return error from the endpoint
Q16: Data-layer will delete those internally when the cancellation is posted and return error if it fails.
Q17: That's a good question. I need to check. I believe they are posted via a dedicated endpoint. Hmm - need to check.
Anyway - ignore Q17 and let's summarize the proposed solution into code for me to use as a reference.1:06 PMLet me check the relevant skills before writing this up.Check frontend design skill for any relevant patternsCheck frontend design skill for any relevant patternsNot the right skill — this is a code reference document, not a Word doc. Let me just write the Python reference code directly.Created a file, ran a command, read a fileCreated a file, ran a command, read a fileHere's the reference implementation. A few things worth flagging:
The rollback caveat is the biggest open issue. Right now if Kafka produce fails, we roll back the CancellationRecord but the trades were already hard-deleted in the same MongoDB transaction. Rolling back the record alone means the trades are gone with no cancellation to explain it. Two paths forward: either switch to soft-delete (a cancelled: bool flag on trades, which the replay filter respects), or accept that on rollback the state is temporarily inconsistent and support just retries. The current code assumes option (b) but I'd push you toward soft-delete — it's a small change that makes the failure mode much cleaner.
The CancellationFilter is the core reusable piece. Both the Intraday service rewind and calculator replay use it identically. It's stateful (tracks parity per key as it advances through messages), so each replay pass gets its own instance.
The nuclear recovery invariant holds because all cancellation timestamps in the ledger predate any message timestamps in a freshly recreated topic, so the filter toggles through all boundaries immediately and lands in PROCESS state for every key.
The main thing to resolve with your team is the topic destination question and the Q17 re-add flow, since that affects whether the CancellationFilter needs to be aware of a second ingestion path.