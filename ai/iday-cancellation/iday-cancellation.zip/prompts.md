# Cancelling Intraday Trade
How to design a future `Cancelling Intraday Trade` in the following setup:
## Microservices
    - Intraday service (FastAPI):
        - consumes raw trade inputs for intraday trades from a `raw_intradays_<date>` kafka topic - considered `the source of truth`. 
        - Transforms to structured trade models. 
        - Saves transformed result to data-layer service.
        - Produces Kafka message with the model data to `enriched_intradays_<date>` topic. This is the "Enriched intraday Trade", consumed by calculator services
    - Data-layer service (FastAPI): CRUD service for saving loading trades and intraday trades, used by the other services to initiate trades state, if they fail
    - Calculator service (N-number of FastApi services):
        - when created (or recovers from failure), each calculator - consumes the `enriched_intradays_<date>` from the beginning, "replaying" all initial intraday inputs (adds and cancellations).
        - Also consumes only trades with version==0 from the data-layer
        - adds all trades to it's calculation engine (internal package) and starts ticking (calculating).
        - after each tick - tries to consume any incoming intradays from the `enriched_intradays_<date>` kafka topic.
        - has the ability to add / remove trades from it's engine on demand.
## Event system
    All services implement and have access to an `Event System` (based on Kafka) with an Event object with data and metadata (metadata contains the event type, a created_at timestamp, created_by field etc.)
## TradeModel
- The trade model has a unique key - a combination of `deal_number`, `portfolio` and `version`. All intraday trades get `version > 0`.
- Trade model with `version==0` is not an intraday trade, but all trades, regardless of the version are stored together in the same mongo collection in the data-layer service
## The Future requested
From time to time intradays trades are posted with wrong data (trade direction buy/sell, etc.), then cancellations are posted, then another intraday trade with same key etc. 
A cancellation in most cases is the same intraday trade data with an inverted value in the relevant fields.
At some point during the day - it may happen that a support team needs to cancel all trades of particular `deal_number` and `portfolio` with `version > 0
Cancellation request will come via an endpoint implemented in the Intraday service.
Cancellation request needs to remove requested trades bundle from the data layer and from calculators, as well as from the intraday service's own internal state.
After that, support team may add new trades, but crucially with the exact same keys (`deal_number`, `portfolio` and `version`)
## The problem to solve
When cancellation request comes intraday service needs to remove trades being `cancelled` from it's internal state and notify the data-layer and calculators about the cancellation event, so they can update their internal state.
However, kafka topics are immutable during the day and the original messages about those trades will remain present in the Kafka topics - `raw_intradays_<date>` and `enriched_intradays_<date>`.
In case of a failure or a restart, Intraday service and Calculators need to "ignore" those original messages and only process any adds / removes after the original cancellation.
Keep in mind that Kafka topics are considered the `source of truth`, but the data-layer can be used as a state backup. We can create new mongo collecitons there at will. For example to store cancellations, state etc.
Propose initial design for this future, but ask me clarifying questions and architecture design questions to help me reason about the problem!

---

Answers:
Q1: It may be just a subset of versions unfortunately.
Q2: It maybe exactly the same with time of arrival as only discriminator.
Q6: At least once is fine - event system handles (ignores) duplicate events.
Q5: Yes, intraday service also replays and also needs to load cancellation events from the data-layer.
Q7: It is acceptable for current tick to complete.
Q8: Ledger is ephemeral per trading day
Q4: Yes, messages are processed in order, there are not that many intradays anyway. Up to 2-3 thousand per day.

---

Answers:
Q3 - yes,
Q9 - yes, but I still insist on using the timestamp
Q10 -Two things here:

* intraday service replays raw topic messages in a "rewinding" mode (a bool flag) in order to re-build it's internal state, but it does not reproduce to the enriched topic. It only appends to it new messages.
* yes it should skip messages for cancelled trades - as if they never arrieved.  When "rewinding" if  incoming messages timestamp is after current cancel event "created_at| time, the event should be poped from the event list (read from the data-layer)  and the next event should be considered as current when checking for trades to ignore.
* my guess, and the reason I want to stick to timestamps,  is that this approach will work even in case of an extreme circumstance, where the services are stopped, topics are deleted and re-created with all new messages. In this case all timestamps on the messages will be after the cancellation events timestamps which will "invalidate" them. This is fine and part of the requirements.
Q11 - ideally yes - I am looking for some kind of transactional element here.

---

On the subtle element with rapid cancellations: This is highly unlikely. Cancellation will be done manually from an UI and there will be 1 to 10 of those per day. Even 10 is maybe to high. 

Q12: I don't need such strong guarantee
Q13: Yes trade keys are provided in the request
Q14: I'd say yes. I'm also thinking of posting cancellation events to a separate `intraday.events` topic and not to the enriched topic, but this I need to discuss with other team members.

---

Q15: Roll back data-layer write and return error from the endpoint
Q16: Data-layer will delete those internally when the cancellation is posted and return error if it fails.
Q17: That's a good question. I need to check. I believe they are posted via a dedicated endpoint. Hmm - need to check.
Anyway - ignore Q17 and let's summarize the proposed solution into code for me to use as a reference.