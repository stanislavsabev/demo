<#
.SYNOPSIS
    Sets up the TI Toolkit development environment.

.DESCRIPTION
    Creates a Python virtual environment, installs both ti-toolkit (core + CLI)
    and ti-toolkit-ui (PySide6 app) in editable mode with dev dependencies.

    After running this script:
      - ti-toolkit-cli   → runs the core CLI
      - ti-toolkit        → launches the PySide6 UI

.PARAMETER PythonPath
    Path to the Python interpreter. Defaults to "python".

.PARAMETER VenvDir
    Name of the virtual environment directory. Defaults to ".venv".

.EXAMPLE
    .\scripts\install.ps1
    .\scripts\install.ps1 -PythonPath "python3.12" -VenvDir ".my-venv"
#>

param(
    [string]$PythonPath = "python",
    [string]$VenvDir = ".venv"
)

$ErrorActionPreference = "Stop"

$RepoRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)

Push-Location $RepoRoot
try {
    # ── Verify Python ──────────────────────────────────────────────
    Write-Host "Checking Python..." -ForegroundColor Cyan
    try {
        $pyVersion = & $PythonPath --version 2>&1
        Write-Host "  Found: $pyVersion"
    }
    catch {
        Write-Error "Python not found at '$PythonPath'. Install Python 3.11+ or pass -PythonPath."
        exit 1
    }

    # ── Create venv ────────────────────────────────────────────────
    $VenvPath = Join-Path $RepoRoot $VenvDir

    if (Test-Path $VenvPath) {
        Write-Host "Virtual environment already exists at $VenvDir" -ForegroundColor Yellow
    }
    else {
        Write-Host "Creating virtual environment in $VenvDir..." -ForegroundColor Cyan
        & $PythonPath -m venv $VenvPath
    }

    # ── Activate venv ──────────────────────────────────────────────
    $ActivateScript = Join-Path $VenvPath "Scripts" "Activate.ps1"
    if (-not (Test-Path $ActivateScript)) {
        Write-Error "Cannot find activation script at $ActivateScript"
        exit 1
    }

    Write-Host "Activating virtual environment..." -ForegroundColor Cyan
    . $ActivateScript

    # ── Upgrade pip ────────────────────────────────────────────────
    Write-Host "Upgrading pip..." -ForegroundColor Cyan
    python -m pip install --upgrade pip --quiet

    # ── Install packages ───────────────────────────────────────────
    Write-Host "Installing ti-toolkit (core + CLI)..." -ForegroundColor Cyan
    pip install -e "src/toolkit[dev]" --quiet

    Write-Host "Installing ti-toolkit-ui (PySide6 app)..." -ForegroundColor Cyan
    pip install -e "src/toolkit_ui[dev]" --quiet

    # ── Verify ─────────────────────────────────────────────────────
    Write-Host ""
    Write-Host "Installation complete!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Installed commands:" -ForegroundColor Cyan
    Write-Host "  ti-toolkit-cli   - Core CLI"
    Write-Host "  ti-toolkit       - PySide6 desktop app"
    Write-Host ""
    Write-Host "To activate the environment in a new shell:" -ForegroundColor Cyan
    Write-Host "  . $VenvDir\Scripts\Activate.ps1"
}
finally {
    Pop-Location
}
