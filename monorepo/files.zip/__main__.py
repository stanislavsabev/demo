"""TI Toolkit UI entry point."""

import sys

from PySide6.QtWidgets import QApplication

from toolkit_ui._version import __version__
from toolkit_ui.main_window import MainWindow


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("TI Toolkit")
    app.setApplicationVersion(__version__)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
