"""TI Toolkit CLI entry point."""

import sys

from toolkit._version import __version__


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "--version":
        print(f"ti-toolkit-cli {__version__}")
        return

    print(f"TI Toolkit CLI v{__version__}")
    # TODO: add argparse / click CLI here


if __name__ == "__main__":
    main()
