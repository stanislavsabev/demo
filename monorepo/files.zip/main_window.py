"""Main application window."""

from PySide6.QtWidgets import QLabel, QMainWindow, QVBoxLayout, QWidget

from toolkit_ui._version import __version__


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"TI Toolkit v{__version__}")
        self.setMinimumSize(800, 600)

        central = QWidget()
        self.setCentralWidget(central)

        layout = QVBoxLayout(central)
        layout.addWidget(QLabel(f"TI Toolkit v{__version__}"))
